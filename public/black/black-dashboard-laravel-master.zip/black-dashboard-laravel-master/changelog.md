# Changelog

All notable changes to `Black Dashboard` frontend preset for Laravel will be documented in this file.

## Version 1.0.0

### Added
- Black Dashboard v1.0.0 frontend theme
- Laravel Auth preset
- Change user profile
- User CRUD

## Version 1.0.1
  - Link to the pro theme

## Version 1.0.2 - 1.0.3
  - Bugs fix
  
## Version 1.0.4 - 2019-09-23

  - Update to Laravel 6.x
  
## Version 1.0.5 - 2020-03-18

  - Update to Laravel 7.x
  
## Version 1.0.6 - 2020-09-23

  - Update to Laravel 8.x

